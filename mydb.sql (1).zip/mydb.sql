-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2023 at 09:52 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `name` text NOT NULL,
  `email` text NOT NULL,
  `message` text NOT NULL,
  `dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`name`, `email`, `message`, `dt`) VALUES
('Unnati', 'unnati@gmail.com', 'looking for more information...', '2023-05-24 01:41:27'),
('Unnati', 'unnati@gmail.com', 'looking for more information...', '2023-05-24 01:41:36'),
('unnati', 'abc@gmail.com', 'welcome', '2023-05-24 01:56:00'),
('isha', 'isha@gmail.com', 'welcome', '2023-05-25 00:45:23');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `name` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`name`, `link`) VALUES
('IGNOU Environment & Ecology', 'https://www.aspireias.com/uploads/Free_Material/IGNOU_Books/IGNOU_Ethics.pdf'),
('IGNOU Environment & Ecology', 'https://www.aspireias.com/uploads/Free_Material/IGNOU_Books/IGNOU_Ethics.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `fmail` text NOT NULL,
  `fpassword` varchar(12) NOT NULL,
  `dt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`fmail`, `fpassword`, `dt`) VALUES
('isha@gmail.com', 'hello', '2023-05-23 19:00:07'),
('isha@gmail.com', 'hello', '2023-05-23 19:00:14'),
('unnati@gmail.com', '1234', '2023-05-23 19:03:01'),
('alpa', '2345', '2023-05-23 19:38:07'),
('jagdish', '12234', '2023-05-23 23:37:49'),
('jagdish', '12234', '2023-05-23 23:38:12'),
('unnati', '456', '2023-05-23 23:42:45'),
('unnati', 'dnks', '2023-05-23 23:44:00'),
('unnati', 'dfjs', '2023-05-23 23:44:36'),
('shinchan', '1234', '2023-05-24 00:08:35'),
('34', '123', '2023-05-24 00:10:09'),
('JUSTINBIEBER@GMAIL.COM', '123', '2023-05-24 18:48:48'),
('moksha@gmail.com', '000', '2023-05-24 23:47:42'),
('moksha@gmail.com', '000', '2023-05-24 23:48:56'),
('JUSTINBIEBER@GMAIL.COM', '123', '2023-05-24 23:58:40'),
('parikh@ymail.com', '12', '2023-05-25 00:28:39'),
('dua@lipa.com', '123', '2023-05-25 00:29:48');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
